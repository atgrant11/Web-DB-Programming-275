from django.db import models
from datetime import datetime

# Create your models here.
class State(models.Model):
    abbrev = models.CharField(max_length = 2)
    state_name = models.CharField(max_length = 20)

    def __str__(self):
        return(self.state_name)
    
class Customer(models.Model):
    first_name = models.CharField(max_length = 30)
    last_name = models.CharField(max_length = 30)
    address = models.CharField(max_length = 50)
    city = models.CharField(max_length = 30)
    state = models.OneToOneField(State, on_delete = models.CASCADE)
    zipcode = models.CharField(max_length = 9)
    phone = models.CharField(max_length = 10)

    def __str__(self):
        return(self.full_name)
    
    @property
    def full_name(self):
        return '%s %s' % (self.last_name, self.first_name)
    
class Order(models.Model):
    description = models.CharField(max_length = 25)
    cost = models.DecimalField(max_digits = 8, decimal_places = 2)
    order_date = models.DateField(default = datetime.today, blank = True)

    def __str__(self):
        return str(self.id)

class CustomerOrder(models.Model):
    customer = models.ForeignKey(Customer, on_delete = models.CASCADE)
    order = models.OneToOneField(Order, on_delete = models.CASCADE)
    