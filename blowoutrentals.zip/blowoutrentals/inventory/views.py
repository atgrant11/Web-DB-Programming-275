from django.shortcuts import render

# Create your views here.
def inventoryPageView(request):
    return render (request, 'inventory/instruments.html')

def showTrumpetPageView(request, name, price):
    context = {
        "name": name,
        "price": price
    }
    return render (request, 'inventory/showTrumpet.html', context)