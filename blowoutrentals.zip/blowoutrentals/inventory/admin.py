from django.contrib import admin
from .models import State
from .models import Customer
from .models import Order
from .models import CustomerOrder

# Register your models here.
admin.site.register(State)
admin.site.register(Customer)
admin.site.register(Order)
admin.site.register(CustomerOrder)