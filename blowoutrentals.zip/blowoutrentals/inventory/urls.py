from django.urls import path
from .views import inventoryPageView
from .views import showTrumpetPageView

urlpatterns = [
    path("inventory/", inventoryPageView, name="inventory"),
    path("inventory/<str:name>/<int:price>/", showTrumpetPageView, name="showTrumpet"),
]